# 请求代理解决跨域

# 开始

安装依赖

yarn install

开始

npm run start

本地发请求调试
npm run debug